<?php
define('ROOT_DATA', ROOT.'data/');
define('ROOT_CORE', ROOT.'core/');
define('ROOT_CONF', ROOT_CORE.'config/');
define('ROOT_URL', 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

//设置通用加密key
define('CONF_KEY', 'Ab0o23O6^&@(Bsg0987_~rmq');
//导入自定义方法
require_once ROOT_CORE.'common.php';
$url = parse(ROOT_URL);
$app = isset($url['expath'][1])?$url['expath'][1]:'';
$ignore_uri = $app;
$app = strtolower($app);
if(in_array($app, array('admin'))){
	//修改核心代码
	define('IGNORE_URI', $ignore_uri);
}else{
	$app='home';
}
define('APP', $app);